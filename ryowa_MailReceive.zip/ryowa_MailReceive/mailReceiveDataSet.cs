﻿namespace ryowa_MailReceive
{
}

namespace ryowa_MailReceive
{


    public partial class mailReceiveDataSet
    {
    }
}
